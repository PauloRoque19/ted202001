/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visao;

import java.util.ArrayList;
import modelo.Jogo;
import modelo.Jogo2D;
import modelo.Jogo3D;
import modelo.JogoRA;
import modelo.JogoRV;
import modelo.JogoTabuleiro;


/**
 *
 * @author Paulinho
 */
public class Compra {
    //Atributos
     
     private int tempo;
     private Cliente cliente;
    
    Cliente c1 = new Cliente(0701,"Cleyson");
    Funcionario f1 = new Funcionario(9090,"Joaquin","Locadora PlayParaiba");
    
    
    
    Jogo2D J1 = new Jogo2D("Computador",2,1965,"JUGYTIP");
    JogoRV J2 = new JogoRV("Capacete Ocular","SIM",2015,"OlharVision");
    JogoRA J3 = new JogoRA("Celular","SIM",2016,"Nitendo");
    Jogo3D J4 = new Jogo3D("Nitendo 3D",3,2010,"Nitendo");
    JogoTabuleiro j5 = new JogoTabuleiro("RPG");
    
    private ArrayList<Jogo>jogo = new ArrayList<Jogo>();
     
     //Metodos
     
     public float CalcularCompra(){
         float x = J1.getPrecoAluguel();
         return x;
     }
    
     
     
     public static void main(String[] args) {
    
    Cliente c1 = new Cliente(0701,"Cleyson");
    Funcionario f1 = new Funcionario(9090,"Joaquin","Locadora PlayParaiba");
    
    Jogo2D J1 = new Jogo2D("Computador",2,1965,"JUGYTIP");
    JogoRV J2 = new JogoRV("Capacete Ocular","SIM",2015,"OlharVision");
    JogoRA J3 = new JogoRA("Celular","SIM",2016,"Nitendo");
    Jogo3D J4 = new Jogo3D("Nitendo 3D",3,2010,"Nitendo");
    JogoTabuleiro J5 = new JogoTabuleiro("RPG");
        
    J1.setPrecoAluguel(20.0f);
    J2.setPrecoAluguel(15.0f);
    J3.setPrecoAluguel(30.0f);
    J4.setPrecoAluguel(12.0f);
    J5.setPrecoAluguel(24.0f);
    
    System.out.println(J1.toString());
    
    }
     
}
