/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visao;

import modelo.Jogo;

/**
 *
 * @author Paulinho
 */
public class Funcionario {
    //Atributos
    private int idFunc;
    private String nomeFunc;
    private String filial;
    //Construtor

    public Funcionario(int idFunc, String nomeFunc, String filial) {
        this.idFunc = idFunc;
        this.nomeFunc = nomeFunc;
        this.filial = filial;
    }
   
    //gets e sets

    public int getIdFunc() {
        return idFunc;
    }

    public void setIdFunc(int idFunc) {
        this.idFunc = idFunc;
    }

    public String getNomeFunc() {
        return nomeFunc;
    }

    public void setNomeFunc(String nomeFunc) {
        this.nomeFunc = nomeFunc;
    }

    public String getFilial() {
        return filial;
    }

    public void setFilial(String filial) {
        this.filial = filial;
    }
    
    
    //Metodos
    
    public String solicitarAluguel(Jogo idjogo){
        return "Aluguel Solicitado";
    }
    
    public float finalizarCompra(){
        return Integer.parseInt("Comprado com sucesso");
    }
}
