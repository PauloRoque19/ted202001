/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Paulinho
 */
public class JogoRA extends JogoDigital {
    //Atributos
    private String dispositivo;
    private String marcador;

    //construtor

    public JogoRA(String dispositivo, String marcador, int anoCriacao, String produtora) {
        super(anoCriacao, produtora);
        this.dispositivo = dispositivo;
        this.marcador = marcador;
    }

   

    public String getDispositivo() {
        return dispositivo;
    }

    public void setDispositivo(String dispositivo) {
        this.dispositivo = dispositivo;
    }

    public String getMarcador() {
        return marcador;
    }

    public void setMarcador(String marcador) {
        this.marcador = marcador;
    }

    

   
    
}
