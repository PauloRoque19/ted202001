/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Paulinho
 */
public class Jogo2D extends JogoDigital {
    //Atributos
    
    private String dispositivo;
    private int tipoControle;
    
    //Construtor

    public Jogo2D(String dispositivo, int tipoControle, int anoCriacao, String produtora) {
        super(anoCriacao, produtora);
        this.dispositivo = dispositivo;
        this.tipoControle = tipoControle;
    }

    

   

    public String getDispositivo() {
        return dispositivo;
    }

    public void setDispositivo(String dispositivo) {
        this.dispositivo = dispositivo;
    }

    public int getTipoControle() {
        return tipoControle;
    }

    public void setTipoControle(int tipoControle) {
        this.tipoControle = tipoControle;
    }
    
    
    
}
