/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Paulinho
 */
public class JogoRV extends JogoDigital{
    //Atributos
    private String tipoCapacete;
    private String estereoscopia;

    //Construtor

    public JogoRV(String tipoCapacete, String estereoscopia, int anoCriacao, String produtora) {
        super(anoCriacao, produtora);
        this.tipoCapacete = tipoCapacete;
        this.estereoscopia = estereoscopia;
    }

    

    public String getTipoCapacete() {
        return tipoCapacete;
    }

    public void setTipoCapacete(String tipoCapacete) {
        this.tipoCapacete = tipoCapacete;
    }

    public String getEstereoscopia() {
        return estereoscopia;
    }

    public void setEstereoscopia(String estereoscopia) {
        this.estereoscopia = estereoscopia;
    }
    
    
    //Metodos
    @Override
    public float calcularTotal(){
        float c = this.getPrecoAluguel();
        return c;
    }
    
}
