/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.util.ArrayList;

/**
 *
 * @author Paulinho
 */
public class JogoTabuleiro extends Jogo {
   //atributos
   private String estilo;
   private ArrayList<String>adereco = new ArrayList<String>();

    
   
   //Construtor
   public JogoTabuleiro(String estilo) {
        this.estilo = estilo;
    }

    //gets e sets
    public String getEstilo() {
        return estilo;
    }

    public void setEstilo(String estilo) {
        this.estilo = estilo;
    }

    public ArrayList<String> getAdereco() {
        return adereco;
    }

    public void setAdereco(ArrayList<String> adereco) {
        this.adereco = adereco;
    }

    

    @Override
    public float calcularTotal() {
        float v1 = this.getPrecoAluguel();
       return v1;

    }
}