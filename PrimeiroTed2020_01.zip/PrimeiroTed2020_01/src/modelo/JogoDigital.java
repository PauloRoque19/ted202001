/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Paulinho
 */
public class JogoDigital extends Jogo {

    
    
    private int anoCriacao;
    private String produtora;

    public JogoDigital(int anoCriacao, String produtora) {
        this.anoCriacao = anoCriacao;
        this.produtora = produtora;
    }

    public int getAnoCriacao() {
        return anoCriacao;
    }

    public void setAnoCriacao(int anoCriacao) {
        this.anoCriacao = anoCriacao;
    }

    public String getProdutora() {
        return produtora;
    }

    public void setProdutora(String produtora) {
        this.produtora = produtora;
    }
    
  
    

    @Override
    public float calcularTotal() {
       float v = this.getPrecoAluguel();
       return v;
    }
    
    
}
