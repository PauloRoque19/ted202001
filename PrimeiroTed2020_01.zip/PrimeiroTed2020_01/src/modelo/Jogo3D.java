/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Paulinho
 */
public class Jogo3D extends JogoDigital{
    //Atributos
    
    private String console;
    private int tipoConsole;

    public Jogo3D(String console, int tipoConsole, int anoCriacao, String produtora) {
        super(anoCriacao, produtora);
        this.console = console;
        this.tipoConsole = tipoConsole;
    }

    

    public String getConsole() {
        return console;
    }

    public void setConsole(String console) {
        this.console = console;
    }

    public int getTipoConsole() {
        return tipoConsole;
    }

    public void setTipoConsole(int tipoConsole) {
        this.tipoConsole = tipoConsole;
    }

    
    
}
